from transformers import AutoTokenizer
import transformers
import torch

model_name = "SharathKapilavai/llama-2-7b-tosca-trained"
prompt = "Compose a TOSCA Simple Profile 1.3 template for deploying a 3-tier application, encompassing web server, application server, and database components, alongside compute nodes for hosting. Include customizable inputs for defining properties such as image, CPU, memory, architecture, OS type, and storage allocation, while establishing relationships to denote the hosting topology within the application architecture"

tokenizer = AutoTokenizer.from_pretrained(model_name)
pipeline = transformers.pipeline(
    "text-generation",
    model=model_name,
    device_map="auto", torch_dtype=torch.float16
)


sequences = pipeline(
    prompt,
    do_sample=True,
    top_k=10,
    num_return_sequences=1,
    eos_token_id=tokenizer.eos_token_id,
    max_length=200,
)
for seq in sequences:
    print(f"Result: {seq['generated_text']}")