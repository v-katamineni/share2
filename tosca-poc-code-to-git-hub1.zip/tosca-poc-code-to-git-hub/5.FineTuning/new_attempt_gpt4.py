from datasets import load_dataset
from transformers import AutoTokenizer, AutoModelForCausalLM, Trainer, TrainingArguments
from peft import get_peft_model, LoraConfig, TaskType
from bitsandbytes import apply_quantization

# Load and preprocess the dataset
# dataset = load_dataset('csv', data_files='tosca_simple_profile_1.3.csv')
# tokenizer = AutoTokenizer.from_pretrained("meta-llama/LLaMA2")
tokenizer = AutoTokenizer.from_pretrained("NousResearch/Llama-2-7b-chat-hf")


def preprocess_function(examples):
    return tokenizer(examples['input'], padding="max_length", truncation=True, max_length=512)

# tokenized_datasets = dataset.map(preprocess_function, batched=True)

dataset = load_dataset("text", data_files={"train":"../training-data/PEFT-Training-Data.txt"})
train_dataset = dataset["train"]
print('Dataset loaded ', train_dataset, train_dataset.data)

# Define LoRA configuration
lora_config = LoraConfig(   
    task_type=TaskType.CAUSAL_LM,
    inference_mode=False,
    r=8,
    lora_alpha=32,
    lora_dropout=0.1
)

# Load the pre-trained model
# model = AutoModelForCausalLM.from_pretrained("meta-llama/LLaMA2")
model = AutoModelForCausalLM.from_pretrained("NousResearch/Llama-2-7b-chat-hf")

# Apply the PEFT model
model = get_peft_model(model, lora_config)

# Apply 8-bit quantization
model = apply_quantization(model, bits=8)

# Define training arguments
training_args = TrainingArguments(
    output_dir='./results',
    num_train_epochs=3,
    per_device_train_batch_size=1,
    per_device_eval_batch_size=1,
    warmup_steps=500,
    weight_decay=0.01,
    logging_dir='./logs',
    logging_steps=10,
    no_cuda=True
)

# Initialize the Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset
)


# Fine-tune the model
trainer.train()

# Evaluate the model
eval_results = trainer.evaluate()
print(f"Perplexity: {eval_results['eval_loss']}")

# Save the model
model.save_pretrained('./tosca-fine-tuned-llama2-peft')
tokenizer.save_pretrained('./tosca-fine-tuned-llama2-peft')
