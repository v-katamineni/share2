# import openai
import pinecone
from langchain.document_loaders import PyPDFDirectoryLoader
from langchain_community.document_loaders import DirectoryLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
# from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import Pinecone #this below has been replaced by the below import
from langchain_community.vectorstores import Pinecone #Importing Pinecone class, specifically using the alias PineconeStore for convenience.
#from langchain.llms import OpenAI  #this below has been replaced by the below import
from langchain_community.chat_models import ChatOpenAI
from langchain.embeddings.sentence_transformer import SentenceTransformerEmbeddings
from langchain.text_splitter import LatexTextSplitter
from langchain_community.llms import CTransformers
from langchain.chains.question_answering import load_qa_chain
from io import StringIO
import streamlit as st
# from dotenv import load_dotenv
import time
import base64
from langchain.prompts import PromptTemplate
from sentence_transformers import SentenceTransformer
import ollama
from langchain_groq import ChatGroq

#from langchain.llms import HuggingFaceHub
#The above have been updated recently, so going forward we have to use the below :)

from langchain.llms import HuggingFaceEndpoint
from langchain_community.vectorstores import Chroma
import chromadb
from chromadb.config import Settings
from langchain_core.documents.base import Document

# Due to recent changes from Pinecone team, there are some minor changes we have to implement, as a part of this we Initialize the Pinecone client

#Please update your pinecone-client package version >=3.0.1
from pinecone import Pinecone as PineconeClient #Importing the Pinecone class from the pinecone package
from langchain_community.vectorstores import Pinecone

import os

# os.environ["OPENAI_API_KEY"] = "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"
os.environ["HUGGINGFACEHUB_API_TOKEN"] = "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"

#Function to read documents
def load_docs(directory):
  loader = PyPDFDirectoryLoader(directory)
  documents = loader.load()
  return documents

# Passing the directory to the 'load_docs' function
directory = '../Docs/'


#This function will split the documents into chunks
def split_docs(documents, chunk_size=100, chunk_overlap=5):
  text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
  docs = text_splitter.split_documents(documents)
  return docs

# #This function will split the documents into chunks
# def latex_split_docs(documents, chunk_size=100, chunk_overlap=5):
#   text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
#   docs = text_splitter.split_documents(documents)
#   return docs

# print(len(docs))
#def createIndex_storeEmbeddings():
  #PINECONE###########
  # Set your Pinecone API key
  # Recent changes by langchain team, expects ""PINECONE_API_KEY" environment variable for Pinecone usage! So we are creating it here
  # we are setting the environment variable "PINECONE_API_KEY" to the value and in the next step retrieving it :)
  # os.environ["PINECONE_API_KEY"] = "95ffbef5-680b-447c-80fc-0b3324256851"
  # PINECONE_API_KEY=os.getenv("‘PINECONE_API_KEY’")

  # Initialize the Pinecone client
  # print('Starting to connect to Pinecone...')

  # PineconeClient(api_key=PINECONE_API_KEY, environment="gcp-starter")
  # index_name="tosca-sp"
  # index = Pinecone.from_documents(docs, embeddings, index_name=index_name)

  # print('Created Pinecone Index...')
  # return index

def createIndex_storeEmbeddings():
  # Initialize ChromaDB
         
  placeholder.text('Storing Embeddings in Vector Store...')

  num = 1
  for doc in final_docs:
    #  embedding = embedding_model.encode([doc.page_content])
     collection.add(
     # embeddings=embedding,
     documents=[doc.page_content],
      ids=[f'id_{num}']
     )
     num = num + 1

############ PROMPT ################################
template = """
<s>
[INST] 
<<SYS>>
You are an expert in generating Tosca templates with Simple Profile in Yaml 1.3. You must refer to the examples provided in the prompt. The response should include topology_template,node_templates,requirements, input and output sections. The response must be just a YAML without any additional text or explanation
<</SYS>>
Create a TOSCA Simple Profile 1.3 template for deploying containerized applications, allowing customization of properties like image, CPU, and memory, while also defining service types for orchestration, networking, and ingress control
[/INST] 
tosca_definitions_version: tosca_simple_yaml_1_3

description: Containerized Application Deployment

node_types:
  tosca.nodes.IngressController:
    derived_from: tosca.nodes.Network
    properties:
      controller_type:
        type: string
  tosca.nodes.Container.Orchestration:
    derived_from: tosca.nodes.Root
    properties:
      type:
        type: string
  tosca.nodes.ContainerApplication:
    derived_from: tosca.nodes.Container.Application
    properties:
      image:
        type: string
      cpu:
        type: string
      memory:
        type: string
topology_template:
  node_templates:
    container_1:
      type: tosca.nodes.ContainerApplication
      properties:
        image: { get_input: image_1 }
        cpu: { get_input: cpu_1 }
        memory: { get_input: memory_1 }
    container_2:
      type: tosca.nodes.ContainerApplication
      properties:
        image: { get_input: image_2 }
        cpu: { get_input: cpu_2 }
        memory: { get_input: memory_2 }
    orchestration_service:
      type: tosca.nodes.Container.Orchestration
      properties:
        type: { get_input: orchestration_type }
    network_service:
      type: tosca.nodes.network.Network
      properties:
        service_type: { get_input: network_service_type }
    ingress_controller:
      type: tosca.nodes.network.IngressController
      properties:
        controller_type: { get_input: ingress_controller_type }
  inputs:
    image_1:
      type: string
    cpu_1:
      type: string
    memory_1:
      type: string
    image_2:
      type: string
    cpu_2:
      type: string
    memory_2:
      type: string
    orchestration_type:
      type: string
    network_service_type:
      type: string
    ingress_controller_type:
      type: string
</s>
<s>
[INST]
Develop a TOSCA Simple Profile 1.3 template for deploying cloud infrastructure, enabling specification of architecture, operating system, image, size, and networking configurations, while also facilitating relationships between virtual machines, storage volumes, subnets, and security groups
[/INST]
tosca_definitions_version: tosca_simple_yaml_1_3

description: Cloud Infrastructure Deployment
data_types:
  security_rules:
    properties:
      protocol:
        type: string
      port:
        type: string
      direction:
        type: string
node_types:
  tosca.nodes.network.SecurityGroup:
    derived_from: tosca.nodes.network.Network
    properties:
      rules:
        type: security_rules
  tosca.nodes.Compute.Custom:
    derived_from: tosca.nodes.Compute
    properties:
      architecture:
        type: string
      os_type:
        type: string
      image:
        type: string
      size:
        type: string  
topology_template:
  node_templates:
    virtual_machine_1:
      type: tosca.nodes.Compute.Custom
      properties:
        architecture: { get_input: architecture }
        os_type: { get_input: os_type }
        image: { get_input: image }
        size: { get_input: vm_size }
      requirements:
        - dependency: storage_volume_1
        - dependency: subnet
        - dependency: security_group
    virtual_machine_2:
      type: tosca.nodes.Compute.Custom
      properties:
        architecture: { get_input: architecture }
        os_type: { get_input: os_type }
        image: { get_input: image }
        size: { get_input: vm_size }
      requirements:
        - dependency: storage_volume_2
        - dependency: subnet
        - dependency: security_group
    storage_volume_1:
      type: tosca.nodes.Storage.BlockStorage
      properties:
        name: storage_1
        size: { get_input: storage_size_1 }
    storage_volume_2:
      type: tosca.nodes.Storage.BlockStorage
      properties:
        name: storage_2
        size: { get_input: storage_size_2 }
    subnet:
      type: tosca.nodes.network.Network
      properties:
        cidr: { get_input: subnet_cidr }
    security_group:
      type: tosca.nodes.network.SecurityGroup
      properties:
        rules: { get_input: security_group_rules }
  inputs:
    architecture:
      type: string
    os_type:
      type: string
    image:
      type: string
    vm_size:
      type: string
    storage_size_1:
      type: string
    storage_size_2:
      type: string
    subnet_cidr:
      type: string
    security_group_rules:
      type: security_rules      
</s>
"""
############# PROMPT ##############################

#This function will help us in fetching the top relevent documents from our vector store - Pinecone
def get_similiar_docs(query, k=10):
    #similar_docs = index.similarity_search("", k=k)
    #return similar_docs
    similar_docs = collection.query(
            query_texts=[query], # Chroma will embed this for you
            n_results=2 # how many results to return
    )
    #print(similar_docs)

        # Retrieve similar documents
        # relevant_docs = collection.query(query)
    results = []
    for doc in similar_docs.get('documents'):
    #  print(f'Doc is {doc}')
       for act_doc in doc:
          print(f'Act Doc is {act_doc} \n \n')
          results.append(Document(
             page_content=act_doc)
            )
    return results

#This function will help us get the answer to the question that we raise
def get_answer(relevance_query,query):
  # print('Query is !!!!  \n',query)
  # print('\n \n ')
  #relevant_docs = get_similiar_docs(relevance_query)
  #print('relevant docs >>>> \n',relevant_docs)

  #llm = CTransformers(model='/home/genaiadmin/cli-project/cli-app/src/models/llama-2-7b-chat.ggmlv3.q6_K.bin',model_type='llama', config={'max_new_tokens': 1280, 'temperature': 0.8, 'context_length': 3584})
  llm = ChatGroq(model="llama-3.1-70b-versatile",api_key='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', max_tokens= 1280, temperature = 0.8)
  chain = load_qa_chain(llm, chain_type="stuff")
  #response = chain.run(input_documents=relevant_docs, question=query)
  response = chain.run(input_documents=list(), question=query)

  return response

st.set_page_config(page_title="Create Service Template",
                    page_icon='OASIS',
                    layout='centered',
                    initial_sidebar_state='collapsed')

st.header("Intent driven Service Template...")

form_input = st.text_area('Provide the Intent in Natural Language...', height=150)

submit = st.button("Generate")

our_query = template + """<s>
[INST]""" + '\n'+form_input +'. Include ouput section in the yaml response. The response must be a valid yaml file.Response must not include any additional text apart from TOSCA yaml response' +"""
[/INST]
"""

# Function to download text content as a file using Streamlit
def text_downloader(raw_text):
    # Generate a timestamp for the filename to ensure uniqueness
    timestr = time.strftime("%Y%m%d-%H%M%S")
    
    # Encode the raw text in base64 format for file download
    b64 = base64.b64encode(raw_text.encode()).decode()
    
    # Create a new filename with a timestamp
    new_filename = "tosca_specification_{}_.yaml".format(timestr)
    
    st.markdown("#### Download File ✅###")
    
    # Create an HTML link with the encoded content and filename for download
    href = f'<a href="data:file/txt;base64,{b64}" download="{new_filename}">Click Here!!</a>'
    
    # Display the HTML link using Streamlit markdown
    st.markdown(href, unsafe_allow_html=True)


placeholder = st.empty()

if submit:
    placeholder.text('Input is ' + our_query)
    print('Query is ', our_query)

    placeholder.text('Loading Specifications...')
    #documents = load_docs(directory)
    placeholder.text('Splitting into chunks...')
    #final_docs = split_docs(documents, chunk_size=1500, chunk_overlap=300)
    placeholder.text('Creating Embeddings...')
    #Hugging Face Embeddings
    #embeddings = SentenceTransformer("sentence-transformers/all-mpnet-base-v2")
    #client = chromadb.Client(Settings())
    collection_name = "tosca-sp-1"
  # Create or get a collection in ChromaDB
        
    #collection = client.get_or_create_collection(name=collection_name)
    #ollama.embeddings(model='nomic-embed-text')
    #embeddings = SentenceTransformer("mixedbread-ai/mxbai-embed-large-v1",384)
    placeholder.text('Storing Embeddings in Vector Store...')
    #index = createIndex_storeEmbeddings()
    placeholder.text('Embeddings updated in tosca-simple-profile-1 index of Vector store...')
    placeholder.text('With embeddings and few shot, requesting Llama LLM to generate Service Template... ')
    time.sleep(9)
    #relevance_query = "\'description: Template for deploying a two-tier application servers on 2 servers\'"
    
    relevance_query = 'Get the YAML syntax for tosca_definitions_version, topology_template, node_templates, input and output'
    answer = get_answer(relevance_query,our_query)
    print('\n \n ')
    print('Answer is ............... \n',answer)  
      
    placeholder.empty()
    st.markdown(answer)
    text_downloader(answer)
    #index.delete(delete_all=True)
    #client.delete_collection(name=collection_name)
    #print('Colletion Deleted')

