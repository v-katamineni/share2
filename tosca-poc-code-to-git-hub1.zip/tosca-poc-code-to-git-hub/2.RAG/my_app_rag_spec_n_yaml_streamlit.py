# import openai
import pinecone
from langchain.document_loaders import PyPDFDirectoryLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import DirectoryLoader
# from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import Pinecone #this below has been replaced by the below import
from langchain_community.vectorstores import Pinecone #Importing Pinecone class, specifically using the alias PineconeStore for convenience.
#from langchain.llms import OpenAI  #this below has been replaced by the below import
from langchain_community.chat_models import ChatOpenAI
from langchain.embeddings.sentence_transformer import SentenceTransformerEmbeddings
from langchain.text_splitter import LatexTextSplitter
from langchain_community.llms import CTransformers
from langchain.chains.question_answering import load_qa_chain
from io import StringIO
import streamlit as st
# from dotenv import load_dotenv
import time
import base64
from langchain.prompts import PromptTemplate

#from langchain.llms import HuggingFaceHub
#The above have been updated recently, so going forward we have to use the below :)

from langchain.llms import HuggingFaceEndpoint

# Due to recent changes from Pinecone team, there are some minor changes we have to implement, as a part of this we Initialize the Pinecone client

#Please update your pinecone-client package version >=3.0.1
from pinecone import Pinecone as PineconeClient #Importing the Pinecone class from the pinecone package
from langchain_community.vectorstores import Pinecone

import os

# os.environ["OPENAI_API_KEY"] = "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"
os.environ["HUGGINGFACEHUB_API_TOKEN"] = "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"

#Function to read documents
def load_docs(directory):
  loader = PyPDFDirectoryLoader(directory)
  documents = loader.load()
  return documents

def split_docs_1000(documents, chunk_size=1000, chunk_overlap=20):
  text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
  docs = text_splitter.split_documents(documents)
  return docs

# def load_split_docs(directory):
#   loader = PyPDFDirectoryLoader(directory)
#   documents = loader.load_and_split()
#   return documents

#Function to read yamls
def load_dir_docs(directory):
  loader = DirectoryLoader(directory)
  documents = loader.load()
  return documents

def split_docs_nothing(documents):
  # print('Yamls \n ', documents)
  return documents


#This function will split the documents into chunks
def split_docs(documents, chunk_size=100, chunk_overlap=5):
  text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
  docs = text_splitter.split_documents(documents)
  # print('Spec \n ', docs)
  return docs

from langchain.text_splitter import MarkdownTextSplitter
def split_docs_markdown(documents, chunk_size=1000, chunk_overlap=10):
    markdown_text = "..."
    markdown_splitter = MarkdownTextSplitter(chunk_size, chunk_overlap)
    docs = markdown_splitter.create_documents(documents)
    return docs



from langchain.text_splitter import LatexTextSplitter
def split_docs_latex(documents, chunk_size=1000, chunk_overlap=20):
    latex_splitter = LatexTextSplitter()
    docs = latex_splitter.create_documents(documents)
    return docs


# #This function will split the documents into chunks
# def latex_split_docs(documents, chunk_size=100, chunk_overlap=5):
#   text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
#   docs = text_splitter.split_documents(documents)
#   return docs

# print(len(docs))
def createIndex_storeEmbeddings(docs):
  #PINECONE###########
  # Set your Pinecone API key
  # Recent changes by langchain team, expects ""PINECONE_API_KEY" environment variable for Pinecone usage! So we are creating it here
  # we are setting the environment variable "PINECONE_API_KEY" to the value and in the next step retrieving it :)
  os.environ["PINECONE_API_KEY"] = "f2f590a9-6fa7-44f6-86f9-74afdbfc3725"
  PINECONE_API_KEY=os.getenv("‘PINECONE_API_KEY’")

  # Initialize the Pinecone client
  print('Starting to connect to Pinecone...')

  PineconeClient(api_key=PINECONE_API_KEY, environment="gcp-starter")
  index_name="tosca-simple-profile-1"

  index = Pinecone.from_documents(docs, embeddings, index_name=index_name)

  print('Created Pinecone Index...')
  return index


#This function will help us in fetching the top relevent documents from our vector store - Pinecone
def get_similiar_docs(query, k=1):
    print('Relevance Query is !!!!  \n',query)
    similar_docs = index.similarity_search(query, k=4)
    print('\n Similar docs ', similar_docs)
    return similar_docs

def get_marginal_relevance_docs(query, k=1):
    print('Relevance Query is !!!!  \n',query)
    similar_docs = index.max_marginal_relevance_search(query, k=4)
    print('\n Marginal Relevance docs ', similar_docs)
    return similar_docs

def get_answer(query, relevant_docs):
  print('Actual Query is !!!!  \n',query)
  llm = CTransformers(model='../llama-2-7b-model/llama-2-7b-chat.ggmlv3.q6_K.bin',model_type='llama', config={'max_new_tokens': 1280, 'temperature': 0.8, 'context_length': 3584})
  chain = load_qa_chain(llm, chain_type="stuff")
  response = chain.run(input_documents=relevant_docs, question=query)
  return response


# Function to download text content as a file using Streamlit
def text_downloader(raw_text):
    # Generate a timestamp for the filename to ensure uniqueness
    timestr = time.strftime("%Y%m%d-%H%M%S")
    
    # Encode the raw text in base64 format for file download
    b64 = base64.b64encode(raw_text.encode()).decode()
    
    # Create a new filename with a timestamp
    new_filename = "tosca_specification_rag_.yaml".format(timestr)
    
    st.markdown("#### Download File ✅###")
    
    # Create an HTML link with the encoded content and filename for download
    href = f'<a href="data:file/txt;base64,{b64}" download="{new_filename}">Click Here!!</a>'
    
    # Display the HTML link using Streamlit markdown
    st.markdown(href, unsafe_allow_html=True)


st.set_page_config(page_title="Create Service Template",
                    page_icon='OASIS',
                    layout='centered',
                    initial_sidebar_state='collapsed')

st.header("TOSCA Service Template from Natural Language - RAG")

form_input = st.text_area('Enter the service template details you are in interestd in...', height=150)

submit = st.button("Generate...")

our_query = form_input #+ '. Include ouput section in the yaml response. The response must be a yaml without any additional explanation.'


placeholder = st.empty()

if submit:
    try:
        placeholder.text('Input is ' + our_query)
        print('Query is ', our_query)

        placeholder.text('Loading Specifications & YAMLs...')

        # Passing the directory to the 'load_docs' function
        directory = '../yamls/'
        yamls = load_dir_docs(directory)

        # Passing the directory to the 'load_docs' function
        directory = '../Docs/'
        specs = load_docs(directory)

        placeholder.text('Splitting data into chunks...')
        specs_split = split_docs(specs)
        yamls_split = split_docs_nothing(yamls)

        final_docs= yamls_split + specs_split
        print('Includes both *******************************************************')
        # docs = documents
        placeholder.text('Creating Embeddings...')
        #Hugging Face Embeddings
        embeddings = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
        placeholder.text('Storing Embeddings in Vector Store...')
        index = createIndex_storeEmbeddings(final_docs)
        placeholder.text('Embeddings updated in tosca-simple-profile-1 index of Vector store...')
        
        placeholder.text('Performing Semantic searches...')
    
        query_1 = "provide a yaml that includes tosca_definitions_version"
        answer_1 = get_marginal_relevance_docs(query_1)
        # print('\n \n ')
        # print(' For query Answer is {} \n',our_query, answer_1)

        query_2 = "provide a yaml that includes topology_template"
        answer_2 = get_marginal_relevance_docs(query_2)
        # print('\n \n ')
        # print(' For query Answer is {} \n',our_query, answer_2)


        query_3 = "provide a yaml that includes node_template"
        answer_3 = get_marginal_relevance_docs(query_2)

        print('\n \n  Response for 2-Tier application \n \n')
        query_4 = "provide a TOSCA yaml for a two-tier application"
        answer_4 = get_marginal_relevance_docs(query_3)
        # print('\n \n ')
        # print(' For query Answer is {} \n',our_query, answer_3)

        relevant_docs = answer_1+answer_2+answer_3+answer_4

        # relevance_query = 'node_templates'
        # relevant_docs_4 = get_similiar_docs(relevance_query)
        # print('\n All Relevant Docs ', relevant_docs)
        placeholder.text('With the embeddings created, requesting the model to generate Service Template... This will take sometime...')
        answer = get_answer(our_query,relevant_docs)
        print('\n \n ')
        print('Answer is ............... \n',answer)
        placeholder.empty()
        st.markdown(answer)
        text_downloader(answer)
        index.delete(delete_all=True)
    except:
        print('Got an exception, clearing indexed documents')
        index.delete(delete_all=True)

