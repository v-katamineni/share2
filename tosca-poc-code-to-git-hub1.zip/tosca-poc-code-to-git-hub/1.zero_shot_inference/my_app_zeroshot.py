import openai

import pinecone
from langchain.document_loaders import PyPDFDirectoryLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import Pinecone #this below has been replaced by the below import
from langchain_community.vectorstores import Pinecone #Importing Pinecone class, specifically using the alias PineconeStore for convenience.
#from langchain.llms import OpenAI  #this below has been replaced by the below import
from langchain_community.chat_models import ChatOpenAI
from langchain.embeddings.sentence_transformer import SentenceTransformerEmbeddings
from langchain_community.llms import CTransformers

from langchain.chains.question_answering import load_qa_chain

#from langchain.llms import HuggingFaceHub
#The above have been updated recently, so going forward we have to use the below :)

from langchain.llms import HuggingFaceEndpoint
import streamlit as st
import time
import base64

import os
os.environ["OPENAI_API_KEY"] = "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"
os.environ["HUGGINGFACEHUB_API_TOKEN"] = "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"

# llm = ChatOpenAI()
llm = CTransformers(model='../llama-2-7b-model/llama-2-7b-chat.ggmlv3.q6_K.bin',model_type='llama', config={'max_new_tokens': 1280, 'temperature': 0.8, 'context_length': 3584})
chain = load_qa_chain(llm, chain_type="stuff")

#This function will help us get the answer to the question that we raise
def get_answer(query):
  print('Query is !!!!  \n',query)
  print('\n \n ')
 
  response = llm.invoke(query)
  return response

# our_query = "How to write a TOSCA Simple Version in Yaml 1.3 template?"
# answer = get_answer(our_query)
# print('\n \n ')
# print('Answer is ............... \n',answer)

# our_query = "Can you provide a detailed and complete example of TOSCA Simple Version in Yaml 1.3 consisting of 3 nodes that are related to each other?"

# our_query = "Can you provide a detailed and complete example of TOSCA Simple Version in Yaml 1.3 consisting of" +
# " 3 nodes that are related to each other?"
# our_query = "Can you create a detailed and complete TOSCA Simple Profile template in Yaml 1.3 for deploying a 3-tier application, consisting of web server, application server, and database components, alongside compute nodes for hosting. Just return the Tosca Template yaml without additional explanation. All explanation should be included in the Yaml output"


st.set_page_config(page_title="Create Service Template",
                    page_icon='OASIS',
                    layout='centered',
                    initial_sidebar_state='collapsed')

st.header("Intent driven Service Template - Zero Shot Inference")

form_input = st.text_area('Provide the Intent in Natural Language...', height=150)

submit = st.button("Generate")

our_query = form_input + """ Include ouput section in the yaml response. The response must be yaml.Response must not include any additional text apart from generated TOSCA yaml response"""

# Function to download text content as a file using Streamlit
def text_downloader(raw_text):
    # Generate a timestamp for the filename to ensure uniqueness
    timestr = time.strftime("%Y%m%d-%H%M%S")
    
    # Encode the raw text in base64 format for file download
    b64 = base64.b64encode(raw_text.encode()).decode()
    
    # Create a new filename with a timestamp
    new_filename = "tosca_specification_zeroshot_.yaml".format(timestr)
    
    st.markdown("#### Download File ✅###")
    
    # Create an HTML link with the encoded content and filename for download
    href = f'<a href="data:file/txt;base64,{b64}" download="{new_filename}">Click Here!!</a>'
    
    # Display the HTML link using Streamlit markdown
    st.markdown(href, unsafe_allow_html=True)

placeholder = st.empty()

if submit:
    placeholder.info('Input - \n' + '\'' +our_query + '\'' + ' \n sent to model. waiting for response...')
    # placeholder.text(' Waiting for response. This might take several minutes...')

    answer = get_answer(our_query)
    print('\n \n ')
    print('Answer is ............... \n',answer)
    placeholder.empty()
    st.markdown(answer)
    text_downloader(answer)


